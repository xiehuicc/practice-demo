class DzApiService {
    get() { }
    
    getBizToken(ctx) { }
    
    checkToken(ctx) { }
}

module.exports = DzApiService