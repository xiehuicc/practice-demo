const DzApiService = require('../DzApiService')
const axios = require('axios')
const jwt = require("jsonwebtoken")
const ModuleConfigEntity = require('../../../../core/models/db/ModuleConfigEntity')

class DzApiServiceImpl extends DzApiService {

    async queryByTel(baseUrl, query) {
        let url = baseUrl + "/dz/people/queryByTel";
        return await axios.get(url, { params: query })
    }

    async getIdToken(baseUrl, body, clientToken) {
        let url = baseUrl + "/v1/id_token2"
        const authToken = 'Bearer ' + clientToken
        return await axios.post(url, body, { headers: {'Authorization': authToken} })
    }

    async updateIdToken(baseUrl, body, clientToken) {
        let url = baseUrl + "/v1/updateIdtoken";
        const authToken = 'Bearer ' + clientToken
        return await axios.put(url, body, { headers: {'Authorization': authToken} })
    }


    get() {
        console.log('DzApiServiceImpl.get() ...')
        return 'DzApiServiceImpl.get() ...'
    }

    async getBizToken(ctx) {
        console.log('DzApiServiceImpl.getBizToken() ...')


        const config = await ModuleConfigEntity.findOne({ moduleName: 'dzapi' }).lean(true)
        const archdataBaseUrl = config.content.archdataBaseUrl
        const casApiBaseUrl = config.content.casApiBaseUrl
        const clientToken = config.content.clientToken

        const body = ctx.request.body
        const source = ctx.request.header.source
        const header = ctx.request.header.header
        let headerJson
        if (header) {
            headerJson = JSON.parse(header)
            console.log('request header:', header)
        }
        if (!source || source !== 'ding') {
            return {
                code: 400,
                msg: 'invalid request'
            }
        }
        if (!archdataBaseUrl || !casApiBaseUrl ) {
            return {
                code: 400,
                msg: 'invalid request2'
            }
        }

        let query = {}
        query.tenantId = "master"
        query.params = {}
        query.params.isEmployed = true
        query.params.tel = headerJson ? headerJson.phone : ctx.request.body.mobile

        let queryResult = await this.queryByTel(archdataBaseUrl, query)

        if (queryResult.status === 200 && queryResult.data.code === 200) {
            let accounts = queryResult.data.result
            // 如果传入了租户信息，则按租户id过滤一把
            if (body.tenantId) {
                accounts = accounts.filter(account => { return account.identities[0].tenant._id === body.tenantId })
            }
            if (accounts.length > 1) {
                let tenantInfList = accounts.map(account => {
                    return {
                        "tenantId": account.identities[0].tenant._id,
                        "tenantName": account.identities[0].tenant.name
                    }
                })
                return {
                    code: 200,
                    msg: 'success',
                    model: {
                        "phoneNumber": body.mobile,
                        tenantInfList
                    }
                }
            } else if (accounts.length < 1) {
                return {
                    code: 400,
                    msg: "no identity found by tel:" + body.mobile,
                }
            } else {
                // 查询到唯一信息或过滤出唯一信息
                let idToken = await this.getIdToken(casApiBaseUrl, { params: { _id: accounts[0]._id } }, clientToken)
                if (idToken.status === 200 && idToken.data.status === 200 && idToken.data.refresh_token) {
                    let idToken2 = await this.updateIdToken(casApiBaseUrl, { refreshToken: idToken.data.refresh_token, identityId: accounts[0].identities[0]._id, tenantId: accounts[0].identities[0].tenant._id }, clientToken)
                    if (idToken2.status === 200 && idToken2.data.status === 200 && idToken2.data.result && idToken2.data.result.id_token) {
                        return {
                            code: 200,
                            msg: 'success',
                            model: {
                                peopleId: accounts[0]._id,
                                name: accounts[0].identities[0].profile.name,
                                phoneNumber: query.params.tel,
                                tenantId: accounts[0].identities[0].tenant._id,
                                identityId: accounts[0].identities[0]._id,
                                departmentId: accounts[0].identities[0].organization.organizationId,
                                token: idToken2.data.result.id_token,
                                refreshToken: idToken2.data.result.refresh_token,
                                tenantInfList: null
                            }
                        }
                    } else {
                        return {
                            code: 400,
                            msg: "updateIdToken fail: " + idToken2.data.message
                        }
                    }
                } else {
                    return {
                        code: 400,
                        msg: "getIdToken2 fail: " + idToken.data.message
                    }
                }
            }
        } else {
            // queryByTel 查询失败
            return {
                code: 400,
                msg: queryResult.msg,
            }
        }
    }

    /*
     * checkToken
     */
    checkToken(ctx) {

        const jwtHeader = ctx.request.headers.authorization
        const body = ctx.request.body
        let jwtToken = null
        let decodedInfo = null
        if (jwtHeader && jwtHeader.startsWith('Bearer ')) { 
            jwtToken = jwtHeader.split(' ')[1]
        }
        if (jwtToken) { 
            try {
                decodedInfo = jwt.decode(jwtToken)
            } catch (e) {
                console.log('decode jwt failed: ', e)
            }
        }

        if (!body.sysCode) {
            return {
                code: 400,
                msg: 'param sysCode invalid!'
            }
        } else if (!decodedInfo) {
            return {
                code: 400,
                msg: 'decode jwt failed!'
            }
        } else {
            console.log('check token ok! 3rd system code:', body.sysCode)
            return {
                code: 200,
                msg: 'success',
                data: {
                    peopleId: decodedInfo.peopleId,
                    tel: decodedInfo.tel,
                    tenantId: decodedInfo.tenantId,
                    tenantIdentity: decodedInfo.tenantIdentity
                }
            }
        }
        
    }
}

module.exports = DzApiServiceImpl