let Router = require('koa-router')
const adaptor = require('../../../core/common/adaptor')

const RunningEnv = require('../../../RunningEnv')
// const server = RunningEnv.moduleServersMap.get('dzApiServices')

const router = new Router({
    prefix: '/dzapi'
})

router.get('/', async (ctx) => {
    console.log('RunningEnv=====>', RunningEnv)
    const services = adaptor.adapt('DzApiService')
    let result = {}
    for (const service of services) {
        result = await service.get(ctx.query)
    }
    // return server.get(ctx.query)
    ctx.body = result
})

/* 
  用于与专属钉钉门户系统对接时，客户端在门户系统登录成功的前提下获取业务系统token
  考虑到农信专属钉钉的验证机制（前置网关验证门户系统生成的token）
  置网关校验通过后会在请求头加验证信息，需要校验请求头
*/
router.post('/getBizToken', async (ctx) => {
    const services = adaptor.adapt('DzApiService')
    let result = {}
    for (const service of services) {
        result = await service.getBizToken(ctx)
    }
    ctx.body = result
})

/*
  用于第三方系统校验我们系统的jwt token（我们系统集成的第三方系统，从我们系统免登进入第三方系统的场景下使用）
  需要校验的token需要放在请求头，由Kong进行校验；能通过kong调到该接口就说明token校验成功了
*/
router.post('/checkToken', async (ctx) => {
    const services = adaptor.adapt('DzApiService')
    let result = {}
    for (const service of services) {
        result = await service.checkToken(ctx)
    }
    ctx.body = result
  })

module.exports = router