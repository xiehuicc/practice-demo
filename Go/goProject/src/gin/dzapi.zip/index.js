const dzApiServiceRoutes = require("./routes/dzApiServiceRoutes");
const DzApiServiceImpl = require("./services/impl/DzApiServiceImpl");

module.exports = {

    dzApiImpl: {
        route: dzApiServiceRoutes,
        impl: DzApiServiceImpl
    }
}